# BLOQUE 1

import pandas as pd

def lectura_datos(path):

  pacientes = pd.read_excel(path, sheet_name = 'Pacientes')
  matriz = pd.read_excel(path, sheet_name = 'Matriz_Tratamientos')
  return pacientes, matriz

pacientes, matriz = lectura_datos('datos_clinicos.xlsx')

def obtener_paciente(pacientes, id_paciente):
  return pacientes[pacientes['ID_Paciente'] == id_paciente].iloc[0]

