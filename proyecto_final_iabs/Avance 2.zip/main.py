from lector import lectura_datos, obtener_paciente
from grafo import construir_grafo, dibujar_grafo

pacientes, matriz = lectura_datos('datos_clinicos.xlsx')


def main():
    while True:
        print("="*20, " Sistema de Soporte a Decisiones Clínicas mediante Algoritmos de Búsqueda (SSDC) ", "="*20)

        print("\nOpciones de menú:")
        print("1. Consultar paciente")
        print("2. Salir")

        opc = int(input("¿Cuál es la opción que eliges?: "))

        if opc == 1:
            consultar_paciente()

        elif opc == 2:
            print("Saliendo del sistema...")
            break

        else:
            print("La opción no es correcta.")


def consultar_paciente():
    print("\nIngreso a consultar un paciente...")

    paciente_id = input("¿Cuál es el ID del paciente que va a consultar?: ").strip().upper()

    if paciente_exist(paciente_id):

        p = obtener_paciente(pacientes, paciente_id)

        print("\nPaciente encontrado.")
        print("Información:", p)

        G = construir_grafo(p, matriz)

        print("\nNúmero de nodos:", G.number_of_nodes())
        print("Número de conexiones:", G.number_of_edges())

        dibujar_grafo(G, f"Paciente {paciente_id}")

    else:
        print("\nEl paciente no existe en la base de datos.")

    print("\nOperación finalizada.")


def paciente_exist(paciente):
    return paciente in pacientes["ID_Paciente"].values


main()