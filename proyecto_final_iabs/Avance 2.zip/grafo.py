import networkx as nx 
import matplotlib.pyplot as plt

FACTORES = {"Insuficiencia_Renal": "Multiplicador_Riesgo_Renal",
            "Cardiopatia": "Multiplicador_Riesgo_Cardio",
            "Edad_Avanzada_Fragil": "Multiplicador_Riesgo_Edad",
            "Inmunosupresion": "Multiplicador_Inmuno"}


def pesos_alfa_beta(paciente):
    if paciente['Minimizar_Costo_Financiero'] == 1:
        return 1.5, 100
    return 0.2 , 5000

def construir_grafo(paciente, matriz):
    alfa, beta = pesos_alfa_beta(paciente)

    prod = 1.0
    for factor, col in FACTORES.items():
        if paciente[factor] == 1:
            prod = prod * matriz[col]
    
    costos = matriz['Costo_Financiero_Base'] * alfa + beta * prod

    G = nx.MultiDiGraph()
    for origen, destino, trat, costo, efect in zip(matriz["Fase_Origen"],
                                                    matriz["Fase_Destino"],
                                                    matriz["Tratamiento"],
                                                    costos,
                                                    matriz["Tasa_Efectividad_Base"]):

        G.add_edge(origen, destino, key=trat, tratamiento=trat, costo=costo, efectividad=efect)
    
    return G

def dibujar_grafo(G, titulo="Grafo del paciente", archivo=None):
    pos = nx.spring_layout(G, seed=3)

    nx.draw(
        G, pos,
        with_labels=True,
        node_color="lightblue",
        node_size=2500,
        font_size=8
    )

    etiquetas = {
        (u, v): f"{k}\n{d['costo']:,.0f}"
        for u, v, k, d in G.edges(keys=True, data=True)
    }

    nx.draw_networkx_edge_labels(
        G, pos,
        edge_labels=etiquetas,
        font_size=7
    )

    plt.title(titulo)

    if archivo:
        plt.savefig(archivo, dpi=300, bbox_inches="tight")

    plt.show()